// ---------- src/app.js (V5.3.1: ClickInfo 每个图表独立显示) ----------

// ---------- 初始化 DOM 引用 ----------
const periodSelect = document.getElementById('period');
const startDateInput = document.getElementById('startDate');
const chartsContainer = document.getElementById('chartsContainer');
const buyRecordsDiv = document.getElementById('buyRecords');

// ---------- 初始化月份下拉（1..60） ----------
for (let i = 1; i <= 60; i++) {
  const opt = document.createElement('option');
  opt.value = i;
  opt.textContent = `${i} Month${i > 1 ? 's' : ''}`;
  if (i === 6) opt.selected = true;
  periodSelect.appendChild(opt);
}

// 初始 startDate（默认今天）
startDateInput.value = new Date().toISOString().split('T')[0];

// ---------- 辅助：计算 endDate 与生成日期数组 ----------
function getEndDate(start, months) {
  const date = new Date(start);
  date.setMonth(date.getMonth() + months);
  const today = new Date();
  return date > today ? today.toISOString().split('T')[0] : date.toISOString().split('T')[0];
}

function getDateArray(start, end) {
  const arr = [];
  let dt = new Date(start);
  const last = new Date(end);
  while (dt <= last) {
    arr.push(dt.toISOString().split('T')[0]);
    dt.setDate(dt.getDate() + 1);
  }
  return arr;
}

// ---------- 数据获取 ----------
async function getForexData(start, end) {
  try {
    const url = `https://api.frankfurter.app/${start}..${end}?from=EUR&to=USD`;
    const response = await fetch(url);
    const data = await response.json();
    const rawRates = Object.entries(data.rates).map(([date, val]) => ({ date, eurusd: val.USD }));
    const dates = getDateArray(start, end);

    // 前向填充
    const filled = [];
    let lastVal = rawRates[0] ? rawRates[0].eurusd : 1.0;
    for (let d of dates) {
      const match = rawRates.find(r => r.date === d);
      if (match) lastVal = match.eurusd;
      filled.push({ date: d, eurusd: lastVal });
    }
    return filled;
  } catch (e) {
    console.error('getForexData error', e);
    return [];
  }
}

async function getCryptoData(symbol, start, end) {
  try {
    const toTimestamp = Math.floor(new Date(end).getTime() / 1000);
    const url = `https://min-api.cryptocompare.com/data/v2/histoday?fsym=${symbol}&tsym=USD&limit=2000&toTs=${toTimestamp}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!data.Data || !data.Data.Data) return [];
    return data.Data.Data.map(d => ({
      date: new Date(d.time * 1000).toISOString().split('T')[0],
      price: d.close
    })).filter(d => d.date >= start && d.date <= end);
  } catch (e) {
    console.error('getCryptoData error', e);
    return [];
  }
}

// ---------- 获取颜色 ----------
function getColors() {
  return {
    eur: document.getElementById('eurColor').value,
    btc: document.getElementById('btcColor').value,
    doge: document.getElementById('dogeColor').value,
  };
}

// ---------- 绘制/刷新单个图表 ----------
async function drawChart(wrapper, start, months, colors) {
  const end = getEndDate(start, months);

  // 请求数据
  const [forex, btcRaw, dogeRaw] = await Promise.all([
    getForexData(start, end),
    getCryptoData('BTC', start, end),
    getCryptoData('DOGE', start, end)
  ]);

  const labels = getDateArray(start, end);

  function alignCrypto(raw) {
    const map = new Map(raw.map(d => [d.date, d.price]));
    let last = raw.length > 0 ? raw[0].price : 0;
    return labels.map(d => {
      if (map.has(d)) last = map.get(d);
      return last;
    });
  }

  const eurSeries = forex.map(f => f.eurusd);
  const btcSeries = alignCrypto(btcRaw);
  const dogeSeries = alignCrypto(dogeRaw);

  // canvas
  const canvas = wrapper.querySelector('canvas');
  const ctx = canvas.getContext('2d');

  if (wrapper.chart) wrapper.chart.destroy();

  wrapper.chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'EUR/USD', data: eurSeries, borderColor: colors.eur, fill: false, tension: 0.1 },
        { label: 'BTC/USD', data: btcSeries, borderColor: colors.btc, fill: false, tension: 0.1 },
        { label: 'DOGE/USD', data: dogeSeries, borderColor: colors.doge, fill: false, tension: 0.1 },
      ]
    },
    options: {
      responsive: false,
      plugins: {
        tooltip: {
          callbacks: {
            label: function(ctx) {
              const lbl = ctx.dataset.label || '';
              const val = ctx.formattedValue;
              const date = ctx.label;
              return `${lbl} • ${date} : ${val}`;
            }
          }
        }
      },
      onClick: (event, elements) => {
        const points = wrapper.chart.getElementsAtEventForMode(event, 'nearest', { intersect: true }, true);
        if (!points || points.length === 0) return;
        const p = points[0];
        const dataset = wrapper.chart.data.datasets[p.datasetIndex];
        const idx = p.index;
        const date = wrapper.chart.data.labels[idx];
        const todayValue = dataset.data[idx];
        const prevValue = dataset.data[idx - 1];

        const infoDiv = wrapper.querySelector('.clickInfo');
        if (!infoDiv) return;

        if (prevValue === undefined || prevValue === null) {
          infoDiv.textContent = `${dataset.label} on ${date} — previous day data not available.`;
          return;
        }
        if (prevValue === 0) {
          infoDiv.textContent = `${dataset.label} on ${date} — previous day value is zero, cannot calculate change.`;
          return;
        }
        const change = ((todayValue - prevValue) / prevValue) * 100;
        const sign = change > 0 ? '📈' : (change < 0 ? '📉' : '—');
        infoDiv.textContent = `${dataset.label} on ${date} ${sign} ${change.toFixed(2)}% (today: ${Number(todayValue).toFixed(4)}, prev: ${Number(prevValue).toFixed(4)})`;
      }
    }
  });

  // 下载按钮
  const dlBtn = wrapper.querySelector('.downloadChartBtn');
  if (dlBtn) {
    dlBtn.onclick = () => {
      const link = document.createElement('a');
      link.download = 'chart.png';
      link.href = canvas.toDataURL('image/png', 1.0);
      link.click();
    };
  }
}

// ---------- 设置拖拽买入记录 ----------
function setupChartDragDrop(wrapper) {
  wrapper.addEventListener('dragover', e => e.preventDefault());
  wrapper.addEventListener('dragenter', e => { e.preventDefault(); wrapper.classList.add('drag-over'); });
  wrapper.addEventListener('dragleave', () => wrapper.classList.remove('drag-over'));

  wrapper.addEventListener('drop', async e => {
    e.preventDefault();
    wrapper.classList.remove('drag-over');

    const dataStr = e.dataTransfer.getData('text/plain');
    if (!dataStr) return;
    let buy;
    try { buy = JSON.parse(dataStr); } catch (err) { return; }

    const chart = wrapper.chart;
    if (!chart) {
      alert('Chart not ready.');
      return;
    }

    const idx = chart.data.labels.findIndex(d => d === buy.date);
    if (idx === -1) {
      alert('Buy date is out of the chart range.');
      return;
    }

    const originDs = chart.data.datasets.find(ds => ds.label && ds.label.includes(buy.currency));
    const valueAtDate = originDs ? originDs.data[idx] : null;

    const marker = {
      label: `Buy ${buy.currency} ${buy.date} x${buy.amount} → ${buy.advice || ''}`,
      data: chart.data.labels.map((d, i) => i === idx ? (valueAtDate !== null ? valueAtDate : null) : null),
      borderColor: 'rgba(220,20,60,0.9)',
      backgroundColor: 'rgba(220,20,60,0.9)',
      pointStyle: 'triangle',
      pointRadius: 8,
      showLine: false,
      fill: false,
    };
    chart.data.datasets.push(marker);
    chart.update();
  });
}

// ---------- 初始化第一个图表 ----------
(async function initFirstChart() {
  const firstWrapper = chartsContainer.querySelector('.chart-wrapper');
  await drawChart(firstWrapper, startDateInput.value, parseInt(periodSelect.value), getColors());

  const delBtn = firstWrapper.querySelector('.deleteChartBtn');
  delBtn.onclick = () => { firstWrapper.remove(); };

  setupChartDragDrop(firstWrapper);
})();

// ---------- 控件事件 ----------
document.getElementById('fetchData').onclick = async () => {
  const wrappers = chartsContainer.querySelectorAll('.chart-wrapper');
  const colors = getColors();
  const months = parseInt(periodSelect.value);
  const start = startDateInput.value;
  for (let w of wrappers) await drawChart(w, start, months, colors);
};

document.getElementById('addChart').onclick = async () => {
  const newWrapper = document.createElement('div');
  newWrapper.className = 'chart-wrapper';
  newWrapper.innerHTML = `
    <canvas class="chartCanvas" width="800" height="400"></canvas>
    <button class="downloadChartBtn">💾 Download PNG</button>
    <button class="deleteChartBtn">🗑 Delete</button>
    <div class="clickInfo">📊 Click on any data point in chart to see daily change information.</div>
  `;
  chartsContainer.appendChild(newWrapper);
  const delBtn = newWrapper.querySelector('.deleteChartBtn');
  delBtn.onclick = () => { newWrapper.remove(); };
  await drawChart(newWrapper, startDateInput.value, parseInt(periodSelect.value), getColors());
  setupChartDragDrop(newWrapper);
};

// ---------- Buy Simulator ----------
const simulateBtn = document.getElementById('simulateBuy');
simulateBtn.onclick = () => {
  const date = document.getElementById('buyDate').value;
  const currency = document.getElementById('buyCurrency').value;
  const amount = parseFloat(document.getElementById('buyAmount').value);
  if (!date || !currency || !amount) return alert('Please fill all fields');

  const record = document.createElement('div');
  record.className = 'buy-record';
  record.draggable = true;
  record.textContent = `${currency} on ${date} x${amount}`;
  record.dataset.buy = JSON.stringify({ date, currency, amount });
  record.ondragstart = e => e.dataTransfer.setData('text/plain', record.dataset.buy);
  buyRecordsDiv.appendChild(record);
};
